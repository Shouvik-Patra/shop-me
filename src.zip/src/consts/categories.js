const categories = [
  {id: '1', name: 'pizza', image: require('../assets/catergories/pizza.png')},
  {id: '2', name: 'Burger', image: require('../assets/catergories/burger.png')},
  {id: '3', name: 'Sushi', image: require('../assets/catergories/sushi.png')},
  {id: '4', name: 'Salad', image: require('../assets/catergories/salad.png')},
];

export default categories;
