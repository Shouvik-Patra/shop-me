
export const Colors = {
    white :"#fff",
    tranparentBlack :'rgba(0, 0, 0, .5)',
    black :"#000",
    bule : "#224585",
    primaryColor :"#9370DB",
    red : 'red',
    mainblue:'#4785ff',
    green : 'green',
    silver : "silver",
    lightSilver :'#d8d8d8',
};


export const Fonts = {
   latoRegular : "Lato-Regular",
   latoBlack :"Lato-Black",
   latoBlackItalic :"Lato-BlackItalic",
   latoBold :"Lato-Bold",
   latoBoldItalic :"Lato-BoldItalic",
   latoItalic :"Lato-Italic",
   latoLight :"Lato-Light",
   latoLightItalic :"Lato-LightItalic",
   latoThin :"Lato-Thin",
   latoThinItalic :"Lato-ThinItalic"

};
